//___FILEHEADER___

import UIKit

class ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_cocoaTouchSubclass___ {

    /// 用户行为
    enum Action {
 
    }
    
    /// 状态变化
    enum Mutation {

    }
    
    /// 页面状态
    struct State {

    }
    
    /// 页面状态
    let initialState: State
    
    
    init() {
        self.initialState = State()
    }
    
    /// Action -> Mutation 的转换
    func mutate(action: Action) -> Observable<Mutation> {

    }

    /// Mutation -> State 的转换
    func reduce(state: State, mutation: Mutation) -> State {

    }
}
