//___FILEHEADER___

import UIKit

/// <#Description#>
class ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_cocoaTouchSubclass___ {

    // MARK: - override
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.setupUI()
    }
    
    // MARK: - UI
    
    /// 设置UI
    private func setupUI() {
        
    }
    
    // MARK: - event
    
    
    // MARK: - public method
    
    
    // MARK: - private method
    
    
    // MARK: - api
    
}

// MARK: - delegate

extension ___FILEBASENAMEASIDENTIFIER___ {
    
}
