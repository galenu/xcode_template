//___FILEHEADER___

import UIKit

/// <#Description#>
class ___FILEBASENAMEASIDENTIFIER___: ___VARIABLE_cocoaTouchSubclass___ {

}
